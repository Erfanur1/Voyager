import Foundation

struct Config {
   
    static let weatherAPIKey = "4dc54c78116911b42cebe8ba9261d8f5"
    
    // No API key needed for these 
    static let exchangeRateBaseURL = "https://api.exchangerate-api.com/v4/latest"
    static let countriesBaseURL = "https://restcountries.com/v3.1"
}

